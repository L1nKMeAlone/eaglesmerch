<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>О нас</title>

<div class="wrapper">
    <div class="page-wrapper">
        <div class="page-content">
            <section class="py-4">
                <div class="container">
                    <div class="row g-0">
                        <div class="col-12 col-lg-6">
                            <div>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3224.706807995905!2d61.451079677370224!3d55.144567891033766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x43c5f34c93bce8db%3A0xb8dc9ab7035846c5!2z0JDQu9C80LDQtw!5e0!3m2!1sru!2sru!4v1650299863727!5m2!1sru!2sru"
                                        width="475" height="475" style="border:0;" allowfullscreen=""
                                        loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                                </iframe>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="p-3">
                                <div>
                                    <h3 class="mt-3 mt-lg-0 mb-0">Адрес</h3>
                                    <div class="d-flex align-items-center mt-3 gap-2">
                                        <p class="mb-0">
                                            Копейское ш., 64, Челябинск, Челябинская обл., 454135
                                        </p>
                                    </div>
                                </div>
                                <div class="my-3">
                                    <h3 class="mt-3 mt-lg-0 mb-0 my-3">Номера телефонов</h3>
                                    <div class="d-flex align-items-center mt-3 gap-2">
                                        <p class="mb-0">
                                            +7-(930)-559-2268
                                        </p>
                                    </div>
                                    <div class="d-flex align-items-center mt-3 gap-2">
                                        <p class="mb-0">
                                            +7-(930)-530-2679
                                        </p>
                                    </div>
                                </div>
                                <div class="my-3">
                                    <h3 class="mt-3 mt-lg-0 mb-0 my-3">Электронная почта</h3>
                                    <div class="d-flex align-items-center mt-3 gap-2">
                                        <p class="mb-0">
                                            eaglesmerch@gmail.com
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <hr/>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

