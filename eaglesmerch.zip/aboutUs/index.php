<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

include $_SERVER['DOCUMENT_ROOT'] . '/aboutUs/index.view.php';
