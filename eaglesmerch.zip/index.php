<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$tshirts = $dataProduct->getTshirts();
$sweatshirts = $dataProduct->getSweatshirts();
$products = $dataProduct->getProducts();
$accessories = $dataProduct->getAccessories();
include $_SERVER['DOCUMENT_ROOT'] . '/index.view.php';
