<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $phone_number = $_POST['phone_number'];
    $phone_number = str_replace( " " , "" , $phone_number );
    $phone_number = str_replace( "(" , "" , $phone_number );
    $phone_number = str_replace( ")" , "" , $phone_number );
    $email = $_POST['email'];
    $image = 'profile_image.jpg';
    $password = $_POST['password'];
    $password_repeat = $_POST['password_repeat'];

    if($password === $password_repeat && count($dataUser->findUserEmailForRegister($email)) < 1 && count($dataUser->findUserPhoneForRegister($phone_number)) < 1) {
        $user = $dataRegister->register($name, $surname, $phone_number, $email, $password, $image);
        if($user) {
            $_SESSION['user'] = json_encode($user, JSON_UNESCAPED_UNICODE);
            $_SESSION['auth'] = true;
            header('Location: /');
        }
    } else {
        $_SESSION['errors']['register'] = "Пользователь с такими данными уже зарегистрирован в системе... ";
        header('Location: /');
    }
}
