<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$id = $_GET['id'];
$product = $dataProduct->getProduct($id);
$images = $dataImage->getProductImages($id);
$sizes = $dataProduct->getProductSizes($id);
include $_SERVER['DOCUMENT_ROOT'] . '/products/detailed/index.view.php';