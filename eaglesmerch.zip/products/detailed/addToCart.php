<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['addToCart'])) {
    $user_id = $_POST['user_id'];
    $product_id = $_POST['product_id'];
    $size_id = $_POST['size_id'];
    $product = $dataProduct->findProductInCart($user_id, $product_id, $size_id);
    if($product == False) {
        $dataProduct->addToCart($user_id, $product_id, 1, $size_id);
        header('Location: /products/detailed/index.php?id=' . $product_id);
    } else {
        $newCount = $product->count + 1;
        $dataProduct->updateProductInCart($user_id, $product_id, $newCount, $size_id);
        header('Location: /products/detailed/index.php?id=' . $product_id);
    }





}