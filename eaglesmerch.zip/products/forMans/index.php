<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$products_for_mans = $dataProduct->getProductsForMans();
include $_SERVER['DOCUMENT_ROOT'] . '/products/forMans/index.view.php';
