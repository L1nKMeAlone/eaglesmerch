<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>Мужчинам</title>

<div class="wrapper">
    <main class="main-content">
        <section class="product-area">
            <div class="container product-pb" data-padding-bottom="25">
                <div class="row">
                    <h3 class="text-center p-3">Мужчинам</h3>
                    <div class="col-12">
                        <div class="product-category-tab-wrap">
                            <div class="tab-content product-category-content" id="myTabContent">
                                <div class="tab-pane fade active show" id="mostView" role="tabpanel"
                                     aria-labelledby="most-view-tab">
                                    <div class="row">

                                        <?php foreach ($products_for_mans as $product): ?>
                                            <div class="col-sm-6 col-lg-4 col-xl-3">
                                                <div class="product-item">
                                                    <div class="inner-content">
                                                        <div class="product-thumb">
                                                            <a href="/products/detailed?id=<?= $product->id ?>">
                                                                <img class="w-100"
                                                                     src="/images/<?= $dataImage->getProductImage($product->id)->image ?>"
                                                                     alt="Image-HasTech">
                                                            </a>
                                                        </div>
                                                        <div class="product-desc">
                                                            <div class="product-info">
                                                                <h4 class="title">
                                                                    <a href="/products/detailed?id=<?= $product->id ?>">
                                                                        <?= $product->name ?>
                                                                    </a>
                                                                </h4>
                                                                <div class="prices">
                                                                    <span class="price">
                                                                        <?= $product->price ?> ₽
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
</section>

</main>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/footer/footer.php'; ?>

</div>
