<title><?= $subcategory->name ?></title>
<?php include $_SERVER['DOCUMENT_ROOT'] . "/admin/header/header.php"; ?>
<div class="g-3 mb-4 px-5">
    <div class="jumbotron bg-light px-5 py-3 my-5">
        <h6 class="display-6"><?= $subcategory->name ?> (<?= $category->name ?>)</h6>
    </div>
    <div class="card mb-3">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="/images/<?= $subcategory->image ?>" class="img-fluid rounded-start" alt="post">
            </div>
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <h3>Товары:</h3>
                    <?php foreach($products as $product): ?>
                        <a href="/admin/products/detailed/index.php?id=<?= $product->id ?>" class="card-link">
                            <?= $product->name ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <form action="/admin/subcategories/delete/deleteSubcategory.php" method="post" class="text-end p-3">
                    <a href="/admin/subcategories/detailed/update/index.php?id=<?= $subcategory->id ?>" class="btn btn-outline-success">Редактировать</a>
                    <button type="submit" name="delete" class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить категорию?');">Удалить</button>
                    <input type="hidden" name="id" value="<?= $subcategory->id ?>">
                    <input type="hidden" name="image" value="<?= $subcategory->image ?>">
                </form>
            </div>
        </div>
    </div>
</div>

