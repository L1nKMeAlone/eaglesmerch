<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['update'])) {
//    unset($_SESSION['errors']);

    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $id = $_POST['id'];
    $subcategory = $dataSubcategory->getSubcategory($id);

    [$error, $fileName] = $dataImage->loadImage($validFiletypes, $uploadPath, 'image');
    if ($_FILES['image']['error'] == UPLOAD_ERR_NO_FILE) {
        $fileName = $subcategory->image;
        $error = "";

    } else {
        $dataImage->deleteImage($_SERVER['DOCUMENT_ROOT'] . "/images/" . $subcategory->image);
    }

    if (empty($error)) {
        $dataSubcategory->updateSubcategory($id, $name, $category_id, $fileName);
        header('Location: /admin/subcategories/detailed/index.php?id=' . $id);
    } else {
        $_SESSION['error']['update'] = $error;
        header('Location: /admin/subcategories/detailed/update/index.php?id=' . $id);
    }
}



