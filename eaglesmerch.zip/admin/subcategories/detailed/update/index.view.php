<title><?= $subcategory->name ?></title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php'; ?>

<div class="card mb-3">
    <form action="/admin/subcategories/detailed/update/updateSubcategory.php" method="post" enctype="multipart/form-data" class="row g-0">
        <div class="col-md-8-flex flex-column justify-content-between">
            <div class="card-body">
                <div class="mb-3">
                    <label for="name" class="form-label">Название подкатегории</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= $subcategory->name ?>">
                </div>
                <div class="mb-3">
                    <label for="category_id" class="form-label">Категория</label>
                    <select name="category_id" id="category_id" class="form-control">
                        <?php foreach($categories as $category): ?>
                            <option value="<?= $category->id ?>" <?= $subcategory->category_id == $category->id ? "selected" : ""?>>
                                <?= $category->name ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Выберите файл</label>
                    <input class="form-control" type="file" id="image" name="image">
                </div>

                <div class="text-end">
                    <button class="btn btn-sm btn-outline-info" name="update">Изменить</button>
                </div>
            </div>
            <div class="col-md-4">
                <img src="/images/<?= $subcategory->image ?>" id="loadImage" class="img-fluid rounded-start img-create" alt="post">
            </div>
        </div>
        <input type="hidden" name="id" value="<?= $subcategory->id ?>">
    </form>
</div>

<script>
    let loadImage = document.querySelector("#loadImage"),
        image = document.querySelector("#image");

    image.addEventListener('change', function(e){
        loadImage.src = URL.createObjectURL(e.target.files[0]);
        loadImage.style.display = "block";
        loadImage.onload = function(){
            URL.revokeObjectURL(e.target.src)
        };
    })
</script>
