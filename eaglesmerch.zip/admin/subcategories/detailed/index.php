<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$subcategory = $dataSubcategory->getSubcategory($_GET['id']);
$category = $dataCategory->getCategoryForSubcategory("$subcategory->category_id");
$products = $dataProduct->getProductsInfo($_GET['id']);

include $_SERVER['DOCUMENT_ROOT'] . '/admin/subcategories/detailed/index.view.php';