<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];

    [$errors, $fileNames] = $dataImage->loadImage($validFiletypes, $uploadPath, 'images');

    $fileName = $fileNames[0];
    if(count($errors) == 0) {
        $_SESSION['msg'] = "Файл успешно загружен";
        $_SESSION['alert'] = 'alert-success';
    } else {
        $fileName = 'default.jpg';
    }

    $subcategory = $dataSubcategory->createSubcategory($name, $category_id , $fileName);
    if($subcategory) {
        header('Location: /admin/subcategories/index.php');
        die();
    } else {
        header('Location: /admin/subcategories/add/index.php');
    }
}