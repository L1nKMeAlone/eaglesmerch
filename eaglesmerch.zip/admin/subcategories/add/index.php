<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$subcategories = $dataSubcategory->getSubcategories();
$categories = $dataCategory->getCategories();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/subcategories/add/index.view.php';