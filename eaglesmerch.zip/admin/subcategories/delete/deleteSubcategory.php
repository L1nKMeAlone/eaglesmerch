<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['delete'])) {
    $id = $_POST['id'];
    $image = $_POST['image'];
    if($image == "default.jpg") {
        $_SESSION['msg'] = "Файл успешно удалён";
        $_SESSION['alert'] = 'alert-success';
        $dataSubcategory->deleteSubcategory($id);
        header('Location: /admin/subcategories');
        die();
    } else {
        $error = $dataImage->deleteImage($_SERVER["DOCUMENT_ROOT"] . '/images/' . $image);

        if(empty($error)) {
            $_SESSION['msg'] = "Файл успешно удалён";
            $_SESSION['alert'] = 'alert-success';
            $dataSubcategory->deleteSubcategory($id);
            header('Location: /admin/subcategories');
            die();
        }

        else {
            $_SESSION['msg'] = $error;
            $_SESSION['alert'] = 'alert-danger';
            header('Location: /admin');
            die();
        }
    }



}