<title>Список подкатегорий</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php'?>

<main>
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="d-flex mb-4 align-items-start ">
                <a href="/admin/subcategories/add/index.php" class="btn btn-outline-dark">
                    Добавить подкатегорию
                </a>
            </div>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php foreach($subcategories as $subcategory): ?>
                    <div class="col">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <?= $subcategory->name ?> (<?= $dataCategory->getCategory($subcategory->category_id)->name ?>)
                                    <form action="/admin/subcategories/delete/deleteSubcategory.php" method="post">
                                        <button type="submit" name="delete" class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить категорию?');">Удалить</button>
                                        <input type="hidden" name="id" value="<?= $subcategory->id ?>">
                                        <input type="hidden" name="image" value="<?= $subcategory->image ?>">
                                    </form>
                                </div>
                                <img src="/images/<?= $subcategory->image ?>" style="width: 100%;" class="card-img-top">
                                <div class="card-body d-flex flex-column justify-content-between">
                                    <a href="/admin/subcategories/detailed/index.php?id=<?= $subcategory->id ?>" class="btn btn-dark">Подробнее</a>
                                </div>
                                <input type="hidden" name="id" value="<?= $subcategory->id ?>">
                            </div>

                        </div>
                    </div>
                <?php endforeach ?>
            </div>
        </div>
    </div>
</main>


