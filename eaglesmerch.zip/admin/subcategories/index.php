<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$subcategories = $dataSubcategory->getSubcategories();

include $_SERVER['DOCUMENT_ROOT'] . '/admin/subcategories/index.view.php';