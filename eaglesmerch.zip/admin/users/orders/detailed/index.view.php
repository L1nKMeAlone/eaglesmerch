<title>Заказ пользователя</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<main>
    <div class="album py-5 bg-light">
        <div class="container">
            <h5>Заказчик: <a href="/admin/users/orders/index.php?id=<?= $dataUser->getUser($order->user_id)->id ?>"><?= $dataUser->getUser($order->user_id)->name ?> <?= $dataUser->getUser($order->user_id)->surname ?></a></h5>
            <h5>Заказ от
                <?php $order_date = new DateTime($order->date_of_registration);
                $new_date_format = $order_date->format('d-m-Y');
                str_replace("-", ".", $new_date_format) ?>
                <?= str_replace("-", ".", $new_date_format); ?> - <?= $dataOrder->getOrderDelivery($order->delivery_id)->name ?>
                (<?= $order->name ?>)
            </h5>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <table class="table table-hover">
                    <thead class="table-dark">
                    <tr class="text-center">
                        <th>Изображение</th>
                        <th>Товар</th>
                        <th>Количество</th>
                        <th>Цена</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $final_price = 0?>
                    <?php foreach ($products as $product): ?>
                        <?php $final_price += $product->count * $product->price?>
                        <tr class="text-center align-middle">
                            <td>
                                <a href="/admin/products/detailed/index.php?id=<?= $product->product_id ?>">
                                    <img src="/images/<?= $dataImage->getProductImage($product->product_id)->image ?>"
                                         style="width: 100px;" class="card-img-top">
                                </a>
                            </td>
                            <td>
                                <a href="/admin/products/detailed/index.php?id=<?= $product->product_id ?>" class="nav-link">
                                    <?= $dataProduct->getProduct($product->product_id)->name ?> <?= $product->value ?>
                                </a>
                            </td>
                            <td><?= $product->count ?> шт.</td>
                            <td><?= $product->count * $product->price ?> ₽</td>
                        </tr>
                    <?php endforeach ?>
                    <tr class="text-center align-middle">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Итого: <?= $final_price ?> ₽</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>


