<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$user_id = $_GET['id'];
$orders = $dataOrder->getUserOrders($user_id);
$statuses = $dataOrder->getOrderStatuses();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/users/orders/index.view.php';