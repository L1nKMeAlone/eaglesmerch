<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$users = $dataUser->getUsers();
$roles = $dataUser->getUserRoles();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/users/index.view.php';