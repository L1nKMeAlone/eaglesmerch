<title>Список пользователей</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<main>
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <table class="table table-hover">
                    <thead class="table-dark">
                    <tr class="text-center">
                        <th>Имя</th>
                        <th>Фамилия</th>
                        <th>Email</th>
                        <th>Номер телефона</th>
                        <th>Статус</th>
                        <th>Заказы</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr class="text-center align-middle">
                            <td><?= $user->name ?></td>
                            <td><?= $user->surname ?></td>
                            <td><?= $user->email ?></td>
                            <td><?= $user->phone_number ?></td>
                            <td>
                                <select name="role_id" id="role_id" class="form-control"
                                        onchange="let newRoleId = this.options[this.selectedIndex].value; location.href = 'updateRole.php?userId=<?= $user->id ?>&newRoleId='+newRoleId;">
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?= $role->id ?>" <?= $user->role_id == $role->id ? "selected" : "" ?>
                                                class="text-center">
                                            <?= $role->name ?>
                                        </option>
                                    <?php endforeach ?>
                                </select>
                            </td>
                            <td>
                                <a class="nav-link" href="orders/index.php?id=<?= $user->id ?>">
                                    Подробнее
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
</main>


