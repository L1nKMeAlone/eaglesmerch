<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

$userId = $_GET['userId'];
$newRoleId = $_GET['newRoleId'];
$dataUser->updateUserRole($userId, $newRoleId);
header('Location: /admin/users/index.php');