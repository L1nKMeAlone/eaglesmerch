<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$order_id = $_GET['id'];
$order = $dataOrder->getUserOrder($order_id);
$products = $dataOrder->getOrderedProducts($order_id);
include $_SERVER['DOCUMENT_ROOT'] . '/admin/orders/detailed/index.view.php';