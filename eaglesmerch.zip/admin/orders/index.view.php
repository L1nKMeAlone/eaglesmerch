<title>Заказы</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<main>
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php $today = new DateTime() ?>
                <div>
                    <input type="date" class="form-control order-date" value="<?= $today->format('Y-m-d') ?>">
                </div>
                <table class="table table-hover">
                    <thead class="table-dark">
                    <tr class="text-center">
                        <th>Номер заказа</th>
                        <th>Дата</th>
                        <th>Статус</th>
                    </tr>
                    </thead>
                    <tbody id="orderThead">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>

    async function getDate(date) {

        let response = await fetch(`/admin/orders/orders.php?date=${date}`)
        return await response.json();
    }

    async function start() {

        let data = await getDate($('.order-date').val());
        let div = document.getElementById('orderThead');
        let string = '';
        data.forEach((item) => string += createOrders(item));
        div.innerHTML = string;

    }

    start();

    $('.order-date').on('change', async function () {
        let date = $('.order-date').val();
        let data = await getDate(date);
        let div = document.getElementById('orderThead');
        let string = '';
        data.forEach((item) => string += createOrders(item));
        div.innerHTML = string;
    })

    function createOrders(order) {

        return `
         <tr class="text-center align-middle">
                            <td>
                                <a class="nav-link" href="detailed/index.php?id=${order.id}">${order.id}</a>
                            </td>
                            <td>
                                ${order.date_of_registration}
                            </td>
                            <td>
                                <select name="status_id" id="status_id" class="form-control"
                                        onchange="let newStatusId = this.options[this.selectedIndex].value; location.href = 'updateOrderStatus.php?order_id=${order.id}&user_id=<?= $user_id ?>&new_status_id='+newStatusId;">
                                    <?php foreach ($statuses as $status): ?>
                                        <option value="<?= $status->id ?>" <?= $order->status_id == $status->id ? "selected" : "" ?>
                                                class="text-center">
                                            <?= $status->name ?>
                                        </option>
                                    <?php endforeach ?>
                                </select>
                            </td>
                        </tr>

        `
    }




</script>


