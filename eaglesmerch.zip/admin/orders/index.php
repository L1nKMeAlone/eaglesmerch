<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$today = new DateTime();
$orders = $dataOrder->getOrdersByDate($today->format('Y-m-d'));
$statuses = $dataOrder->getOrderStatuses();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/orders/index.view.php';