<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$orders = $dataOrder->getOrdersByDate($_GET['date']);


echo json_encode($orders,JSON_UNESCAPED_UNICODE);