<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

$order_id = $_GET['order_id'];
$new_status_id = $_GET['new_status_id'];
$user_id = $_GET['user_id'];
$dataOrder->updateOrderStatus($order_id, $new_status_id);
header('Location: /admin/orders/');