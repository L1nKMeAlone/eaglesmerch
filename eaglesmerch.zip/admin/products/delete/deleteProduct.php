<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['delete'])) {
    $id = $_POST['id'];

    $images = $dataImage->getProductImages($id);
    foreach($images as $image) {
        if($image->image !== 'default.jpg') {
            $dataImage->deleteImage($_SERVER["DOCUMENT_ROOT"] . '/images/' . $image->image);
        }

    }

    $dataProduct->deleteProduct($id);

    header('Location: /admin/products/');
}