<title>Список размеров/материалов</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<main>
    <div class="d-flex mb-4 justify-content-between px-5">
        <div class="text-end p-3">
            <a href="/admin/products/detailed/characteristics/add/size/index.php?id=<?= $product->id ?>" class="btn btn-outline-success">
                Добавить размер
            </a>
            <a href="/admin/products/detailed/characteristics/add/material/index.php?id=<?= $product->id ?>" class="btn btn-outline-success">
                Добавить материал
            </a>
        </div>
    </div>

    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <h3>
                    <a href="/admin/products/detailed/index.php?id=<?= $product->id ?>" class="navbar-brand link-dark">
                        <?= $product->name ?>
                    </a>

                </h3>
                <table class="table table-hover">
                    <thead class="table-dark ">
                    <tr class="text-center">
                        <th class="col-1">Материал</th>
                        <th class="col-1">Проценты</th>
                        <th class="col-1"></th>
                        <th class="col-1"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($materials as $material): ?>
                        <tr class="text-center align-middle">
                            <td><?= $material->name ?></td>
                            <td>
                                <?= $material->value ?>
                            </td>
                            <td>
                                <button type="button" onClick="" data-material='<?= json_encode($material) ?>' class="btn btn-outline-success btn-material-edit" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    Редактировать
                                </button>
                            </td>
                            <td>
                                <a href="delete/deleteMaterial.php?id=<?= $material->pr_id ?>&product_id=<?= $product->id ?>"
                                   class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить материал?');">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach ?>

                    </tbody>
                </table>

                <table class="table table-hover">
                    <thead class="table-dark ">
                    <tr class="text-center">
                        <th class="col-1">Размер</th>
                        <th class="col-1">На складе</th>
                        <th class="col-1"></th>
                        <th class="col-1"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($sizes as $size): ?>
                        <tr class="text-center align-middle">
                            <td class="col-1"><?= $size->value ?></td>
                            <td class="col-1"><?= $size->count ?> шт.</td>
                            <td>
                                <button type="button" onClick="" data-size='<?= json_encode($size) ?>' class="btn btn-outline-success btn-size-edit" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                                    Редактировать
                                </button>
                            </td>
                            <td>
                                <a href="delete/deleteSize.php?id=<?= $size->sz_id ?>&product_id=<?= $product->id ?>"
                                   class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить размер?');">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" action="update/updateMaterial.php" method="post">
            <div class="modal-header">
                <h5 class="modal-title material-title-edit" id="exampleModalLabel"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
            </div>
            <div class="modal-body">
                <input type="number" class="form-control value-edit" name="value" placeholder="Введите новое значение...">
            </div>
            <input class='pr-id-edit' type="hidden" name="pr_id">
            <input class="product-id-edit" type="hidden" name="product_id">
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                <button type="submit" class="btn btn-primary" name="update">Сохранить изменения</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" action="update/updateSize.php" method="post">
            <div class="modal-header">
                <h5 class="modal-title size-title-edit" id="exampleModalLabel">222</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
            </div>
            <div class="modal-body">
                <input type="number" class="form-control count-edit" name="count"" placeholder="Введите новое количество...">
            </div>
            <input class='sz-id-edit' type="hidden" name="sz_id">
            <input class="product-id-edit" type="hidden" name="product_id">
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                <button type="submit" class="btn btn-primary btn-material-update" name="update">Сохранить изменения</button>
            </div>
        </form>
    </div>
</div>

<script src="http://code.jquery.com/jquery-latest.js"></script>

<script>

    $('.btn-material-edit').on('click',function(){
        let options = JSON.parse(this.dataset.material);
        console.log(options.value);
        $('.value-edit').val(options.value);
        $('.pr-id-edit').val(options.pr_id);
        $('.product-id-edit').val(options.product_id);

        $('.material-title-edit').text(`Редактировать материал (${options.name})`);

    })

    $('.btn-size-edit').on('click',function(){
        let options = JSON.parse(this.dataset.size);
        console.log(options.value);
        $('.count-edit').val(options.count);
        $('.sz-id-edit').val(options.sz_id);
        $('.product-id-edit').val(options.product_id);
        $('.size-title-edit').text(`Редактировать размер (${options.value})`);
    })

</script>
