<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['update'])) {

    $pr_id = $_POST['pr_id'];
    $value = $_POST['value'];
    $product_id = $_POST['product_id'];
    $dataProduct->updateProductMaterial($pr_id, $value);
    header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
}



