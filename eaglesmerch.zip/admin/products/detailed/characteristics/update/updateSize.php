<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['update'])) {

    $sz_id = $_POST['sz_id'];
    $count = $_POST['count'];
    $product_id = $_POST['product_id'];
    $dataProduct->updateProductSize($sz_id, $count);
    header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
}



