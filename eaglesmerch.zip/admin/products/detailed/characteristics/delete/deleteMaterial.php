<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product_id = $_GET['product_id'];
$pr_id = $_GET['id'];
$dataProduct->deleteProductMaterial($pr_id);
header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);