<title>Новый размер/материал</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<div class="g-3 mb-4 px-5">
    <h3>Материал</h3>
    <div class="card mb-3">
        <form action="/admin/products/detailed/characteristics/add/material/addMaterial.php" method="post"
              enctype="multipart/form-data" class="row g-0">
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <div>
                        <div class="mb-3">
                            <label for="material_id" class="form-label">Название</label>
                            <select name="material_id" id="material_id" class="form-control">
                                <?php foreach($materials_name as $material): ?>
                                    <option value="<?= $material->id ?>">
                                        <?= $material->name ?>
                                    </option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="value" class="form-label">Проценты</label>
                            <input type="text" class="form-control" id="value" name="value"
                                   placeholder="Введите проценты характеристики" required>
                        </div>
                    </div>

                    <input type="hidden" name="product_id" value="<?= $product->id ?>"
                    <div class="text-end">
                        <button class="btn btn-primary" name="submit" type="submit" id="submit">Создать</button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
