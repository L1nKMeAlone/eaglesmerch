<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if (isset($_POST['submit'])) {
    $product_id = $_POST['product_id'];
    $material_id = $_POST['material_id'];
    $value = $_POST['value'];

    $material = $dataProduct->createProductMaterial($product_id, $material_id, $value);
    if($material){
        header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
    } else {
        header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
    }
}