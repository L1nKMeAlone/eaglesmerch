<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product = $dataProduct->getProduct($_GET['id']);
$materials = $dataProduct->getProductMaterials($product_id);
$materials_name = $dataProduct->getMaterialsName();

include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/detailed/characteristics/add/material/index.view.php';