<title>Новый размер</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<div class="g-3 mb-4 px-5">
    <h3>Размер</h3>
    <div class="card mb-3">
        <form action="/admin/products/detailed/characteristics/add/size/addSize.php" method="post"
              enctype="multipart/form-data" class="row g-0">
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <div>
                        <div class="mb-3" >
                            <label for="size_id" class="form-label">Значение</label>
                            <select name="size_id" id="size_id" class="form-control">
                                <?php foreach($sizes_value as $size): ?>
                                    <option value="<?= $size->id ?>">
                                        <?= $size->value ?>
                                    </option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="count" class="form-label">Количество</label>
                            <input type="text" class="form-control" id="count" name="count"
                                   placeholder="Введите количество характеристики" required>
                        </div>
                    </div>

                    <input type="hidden" name="product_id" value="<?= $product->id ?>"
                    <div class="text-end">
                        <button class="btn btn-primary" name="submit" type="submit" id="submit">Создать</button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
