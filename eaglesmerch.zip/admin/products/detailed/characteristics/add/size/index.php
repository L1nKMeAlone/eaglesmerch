<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product = $dataProduct->getProduct($_GET['id']);
$sizes = $dataProduct->getProductSizes($product_id);
$sizes_value = $dataProduct->getSizesValue();

include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/detailed/characteristics/add/size/index.view.php';