<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if (isset($_POST['submit'])) {
    $product_id = $_POST['product_id'];
    $size_id = $_POST['size_id'];
    $count = $_POST['count'];

    $size = $dataProduct->createProductSize($product_id, $size_id, $count);
    if($size){
        header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
    } else {
        header('Location: /admin/products/detailed/characteristics/index.php?id=' . $product_id);
    }


}
