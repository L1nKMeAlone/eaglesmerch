<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product_id = $_GET['id'];
$product = $dataProduct->getProduct($product_id);
$materials = $dataProduct->getProductMaterials($product_id);
$sizes = $dataProduct->getProductSizes($product_id);

include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/detailed/characteristics/index.view.php';