<title><?= $product->name ?></title>
<?php include $_SERVER['DOCUMENT_ROOT'] . "/admin/header/header.php"; ?>
<div class="g-3 mb-4 px-5">
    <div class="jumbotron bg-light px-5 py-3 my-5">
        <h6 class="display-6"><?= $product->name ?> (<?= $category->name ?> / <?= $subcategory->name ?>)</h6>
    </div>
    <div class="mb-3">
        <div class="row g-0">
            <div class="col-md-4 ">
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php foreach($images as $image): ?>
                            <div class="carousel-item" id="image">
                                <img class="d-block w-100" src="/images/<?= $image->image ?>" data-src="holder.js/900x400?theme=social" alt="First slide">
                            </div>
                        <?php endforeach ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Предыдущий</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Следующий</span>
                    </button>
                </div>
            </div>
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <h3>Описание:</h3>
                    <p><?= $product->description ?></p>
                    <h3>Материал:</h3>
                    <?php foreach($materials as $material): ?>
                        <p><?= $material->name ?>: <?= $material->value ?>%</p>
                    <?php endforeach ?>
                    <h3>Размеры:</h3>
                    <p>|
                        <?php foreach($sizes as $size): ?>
                            <?= $size->value ?> |
                        <?php endforeach ?>
                    </p>
                </div>
                <form action="/admin/products/delete/deleteProduct.php" method="post" class="text-end p-3">
                    <a href="/admin/products/detailed/characteristics/index.php?id=<?= $product->id ?>" class="btn btn-outline-success">Размеры/Материалы</a>
                    <a href="/admin/products/detailed/update/index.php?id=<?= $product->id ?>" class="btn btn-outline-success">Редактировать</a>
                    <button type="submit" name="delete" class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить товар?');">Удалить</button>
                    <input type="hidden" name="id" value="<?= $product->id ?>">
                    <input type="hidden" name="image" value="<?= $product->image ?>">
                </form>
            </div>
        </div>
    </div>
</div>




<script>
let images = document.querySelectorAll('#image');
for(let i = 0; i<images.length; i++) {
    images[0].classList.add('active');
    break;
}
</script>
