<title><?= $product->name ?></title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php'; ?>

<div class="card mb-3">
    <form action="/admin/products/detailed/update/updateProduct.php" method="post" enctype="multipart/form-data" class="row g-0">
        <div class="col-md-8-flex flex-column justify-content-between">
            <div class="card-body">
                <div class="mb-3">
                    <label for="name" class="form-label">Название товара</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= $product->name ?>" placeholder="Введите новое название товара..." required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <textarea style="min-height: 150px;" type="text" class="form-control" id="description" name="description" placeholder="Введите новое описание товара..." required><?= $product->description ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="subcategory_id" class="form-label">Податегория</label>
                    <select name="subcategory_id" id="subcategory_id" class="form-control">
                        <?php foreach($subcategories as $subcategory): ?>
                            <option value="<?= $subcategory->id ?>" <?= $product->subcategory_id == $subcategory->id ? "selected" : ""?>>
                                <?= $subcategory->name ?> (<?= $dataCategory->getCategory($subcategory->category_id)->name ?>)
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Цена товара</label>
                    <input type="number" class="form-control" id="price" name="price" value="<?= $product->price ?>" placeholder="Введите новую цену товара..." required>
                </div>
                <div class="text-end">
                    <button class="btn btn-sm btn-outline-info" name="update">Изменить</button>
                </div>
            </div>
        </div>
        <input type="hidden" name="id" value="<?= $product->id ?>">
    </form>
</div>


