<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product = $dataProduct->getProduct($_GET['id']);
$subcategories = $dataSubcategory->getSubcategories();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/detailed/update/index.view.php';