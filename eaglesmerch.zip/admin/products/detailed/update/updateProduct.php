<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['update'])) {

    $name = $_POST['name'];
    $description = $_POST['description'];
    $subcategory_id = $_POST['subcategory_id'];
    $price = $_POST['price'];
    $id = $_POST['id'];
    $dataProduct->updateProduct($id, $name, $description, $subcategory_id, $price);
    header('Location: /admin/products/detailed/index.php?id=' . $id);
}



