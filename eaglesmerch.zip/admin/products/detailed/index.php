<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$product = $dataProduct->getProduct($_GET['id']);
$subcategory = $dataSubcategory->getSubcategory($product->subcategory_id);
$category = $dataCategory->getCategory($subcategory->category_id);
$images = $dataImage->getProductImages($product->id);
$materials = $dataProduct->getProductMaterials($product->id);
$sizes = $dataProduct->getProductSizes($product->id);
include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/detailed/index.view.php';