<title>Новый товар</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>
<div class="g-3 mb-4 px-5">
    <div class="card mb-3">
        <form action="/admin/products/add/createProduct.php" method="post" enctype="multipart/form-data" class="row g-0">
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Название товара</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Введите название товара..." required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Описание</label>
                        <textarea type="text" class="form-control" id="description" name="description" placeholder="Введите описание товара..." required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="subcategory_id" class="form-label">Подкатегория</label>
                        <select name="subcategory_id" id="subcategory_id" class="form-control">
                            <?php foreach($subcategories as $subcategory): ?>
                                <option value="<?= $subcategory->id ?>"><?= $subcategory->name ?>
                                    (<?= $dataCategory->getCategory($subcategory->category_id)->name ?>)</option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Цена товара</label>
                        <input type="number" class="form-control" id="price" name="price" placeholder="Введите цену товара..." required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Выберите файл(ы)</label>
                        <input class="form-control" type="file" id="image" name="images[]" multiple>
                    </div>
                    <div class="text-end">
                        <button class="btn btn-primary" type="submit" name="submit">Создать</button>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <img src="" alt="" id="loadImage" class="img-fluid rounded-start">
            </div>
        </form>
    </div>
</div>

<script>
    let loadImage = document.querySelector("#loadImage"),
        image = document.querySelector("#image")

    image.addEventListener("change", function(e){
        loadImage.src = URL.createObjectURL(e.target.files[0]);
        loadImage.style.display = "block";
        loadImage.onload = function(){
            URL.revokeObjectURL(e.target.src)
        };
    })
</script>
