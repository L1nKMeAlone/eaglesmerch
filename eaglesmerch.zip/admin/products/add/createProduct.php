<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $subcategory_id = $_POST['subcategory_id'];

    [$errors, $upLoadFiles] = $dataImage->loadImage($validFiletypes, $uploadPath, 'images');

    if(count($errors) == 0) {
        $product_id = $dataProduct->createProduct($name, $description, $price, $subcategory_id);
        if($product_id) {
            foreach($upLoadFiles as $image) {
                $dataImage->createImagesFromProduct($product_id, $image);
            }
            header('Location: /admin/products/');
            die();
        } else {
            header('Location: /admin/products/add/index.php');
        }
    } else {
        $product_id = $dataProduct->createProduct($name, $description, $price, $subcategory_id);
        if($product_id) {
            $dataImage->createImagesFromProduct($product_id, 'default.jpg');
            header('Location: /admin/products/');
        } else {
            header('Location: /admin/products/add/index.php');
        }
    }



}