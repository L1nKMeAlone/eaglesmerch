<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$products = $dataProduct->getALlProductsBySubcategory($_GET['id']);


echo json_encode($products,JSON_UNESCAPED_UNICODE);