<title>Список товаров</title>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/header/header.php' ?>


<main>
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="d-flex mb-4 align-items-start ">
                <a href="/admin/products/add/index.php" class="btn btn-outline-dark">
                    Добавить товар
                </a>
                <div class="mx-3">
                    <select name="subcategory_id" id="subcategory_id" class="form-control product-select">
                        <?php foreach ($subcategories as $subcategory): ?>
                            <option value="<?= $subcategory->id ?>">
                                <?= $subcategory->name ?>
                                (<?= $dataCategory->getCategory($subcategory->category_id)->name ?>)
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>

            </div>
            <div class="products-div row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" id="productDiv">

            </div>
        </div>
    </div>
</main>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>

    async function getId(id) {

        let response = await fetch(`/admin/products/products.php?id=${id}`)
        return await response.json();
    }

    async function start() {

        let data = await getId($('.product-select').val());
        let div = document.getElementById('productDiv');
        let string = '';
        data.forEach((item) => string += createProducts(item));
        div.innerHTML = string;

    }

    start();

    $('.product-select').on('change', async function () {

        let id = $('.product-select').val();
        let data = await getId(id);
        let div = document.getElementById('productDiv');
        let string = '';
        data.forEach((item) => string += createProducts(item));
        div.innerHTML = string;

    })


    function createProducts(product) {

        return `<div class="col">
                    <div class="card shadow-sm">
                        <div class="card-body">
                         <div class="d-flex justify-content-between align-items-center">
                       ${product.name}
                        <form action="/admin/products/delete/deleteProduct.php" method="post">
                            <button type="submit" name="delete" class="btn btn-outline-danger"
                                    onclick="return confirm('Вы действительно хотите удалить товар?');">
                                Удалить
                            </button>
                            <input type="hidden" name="id" value="${product.id}">
                        </form>
                    </div>
                    <img src="/images/${product.image}"
                         style="width: 100%;" class="card-img-top">
                        <div class="card-body text-center">
                            <h4>
                                ${product.price} ₽
                            </h4>
                        </div>
                        <div class="card-body d-flex flex-column justify-content-between">
                            <a href="/admin/products/detailed/index.php?id=${product.id}"
                               class="btn btn-dark">Подробнее</a>
                        </div>
                        <input type="hidden" name="id" value="product.id ">
            </div>
</div>
</div>
                `
    }

</script>
