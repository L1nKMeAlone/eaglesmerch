<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

$products = $dataProduct->getAllProductsBySubcategory($_GET['id']);

$subcategories = $dataSubcategory->getSubcategories();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/products/index.view.php';

