<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user = $dataAuth->auth($email, $password);
    if($user){
        if($user->role_id === "2") {
            $_SESSION['user'] = json_encode($user, JSON_UNESCAPED_UNICODE);
            $_SESSION['auth'] = true;
            header('Location: /admin');
        } else {
            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            $_SESSION['errors']['auth'] = 'Вы не являетесь администратором!';
            header('Location: /admin');
        }

    } else {
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        $_SESSION['errors']['auth'] = 'Неправильно введена почта или пароль!';
        header('Location: /admin');
    }

}