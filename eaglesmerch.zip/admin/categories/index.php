<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$categories = $dataCategory->getCategories();
include $_SERVER['DOCUMENT_ROOT'] . '/admin/categories/index.view.php';