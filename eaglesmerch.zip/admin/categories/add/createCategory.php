<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['submit'])) {
    $name = $_POST['name'];

    [$errors, $fileNames] = $dataImage->loadImage($validFiletypes, $uploadPath, 'images');

    $fileName = $fileNames[0];
    if(count($errors) == 0) {
        $_SESSION['msg'] = "Файл успешно загружен";
        $_SESSION['alert'] = 'alert-success';

    } else {
        $fileName = 'default.jpg';
    }

    $category = $dataCategory->createCategory($name, $fileName);
    if($category) {
        header('Location: /admin/categories/index.php');
        die();
    } else {
        header('Location: /admin/categories/add/index.php');
    }


}