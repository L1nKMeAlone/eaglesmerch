<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
include $_SERVER['DOCUMENT_ROOT'] . '/admin/categories/add/index.view.php';