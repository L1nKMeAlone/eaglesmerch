<title><?= $category->name ?></title>
<?php include $_SERVER['DOCUMENT_ROOT'] . "/admin/header/header.php"; ?>
<div class="g-3 mb-4 px-5">
    <div class="jumbotron bg-light px-5 py-3 my-5">
        <h6 class="display-6"><?= $category->name ?></h6>
    </div>
    <div class="card mb-3">
        <div class="row g-0">
            <div class="col-md-4 px-5 py-3 my-3" >
                <img src="/images/<?= $category->image ?>" class="img-fluid rounded-start" alt="post">
            </div>
            <div class="col-md-8 d-flex flex-column justify-content-between">
                <div class="card-body">
                    <h3>Подкатегории:</h3>
                    <?php foreach($subcategories as $subcategory): ?>
                        <p><?= $subcategory->name ?></p>
                    <?php endforeach; ?>
                </div>
                <form action="/admin/categories/delete/deleteCategory.php" method="post"  class="text-end p-3">
                    <a href="/admin/categories/detailed/update/index.php?id=<?= $category->id ?>" class="btn btn-outline-success">Редактировать</a>
                    <button type="submit" name="delete" class="btn btn-outline-danger" onclick="return confirm('Вы действительно хотите удалить категорию?');">Удалить</button>
                    <input type="hidden" name="id" value="<?= $category->id ?>">
                    <input type="hidden" name="image" value="<?= $category->image ?>">
                </form>
            </div>
        </div>
    </div>
</div>

