<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$category = $dataCategory->getCategory($_GET['id']);
$subcategories = $dataSubcategory->getSubcategoriesInfo($_GET['id']);
include $_SERVER['DOCUMENT_ROOT'] . '/admin/categories/detailed/index.view.php';