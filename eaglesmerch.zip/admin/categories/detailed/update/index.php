<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$category = $dataCategory->getCategory($_GET['id']);

include $_SERVER['DOCUMENT_ROOT'] . '/admin/categories/detailed/update/index.view.php';