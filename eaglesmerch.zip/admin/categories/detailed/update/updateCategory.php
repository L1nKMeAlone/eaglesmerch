<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['update'])) {
//    unset($_SESSION['errors']);

    $name = $_POST['name'];
    $id = $_POST['id'];
    $category = $dataCategory->getCategory($id);

    [$error, $fileName] = $dataImage->loadImage($validFiletypes, $uploadPath, 'image');
    if ($_FILES['image']['error'] == UPLOAD_ERR_NO_FILE) {
        $fileName = $category->image;
        $error = "";

    } else {
        $dataImage->deleteImage($_SERVER['DOCUMENT_ROOT'] . "/images/" . $category->image);
    }

    if (empty($error)) {
        $dataCategory->updateCategory($id, $name, $fileName);
        header('Location: /admin/categories/detailed/index.php?id=' . $id);
    } else {
        $_SESSION['error']['update'] = $error;
        header('Location: /admin/categories/detailed/update/index.php?id=' . $id);
    }
}



