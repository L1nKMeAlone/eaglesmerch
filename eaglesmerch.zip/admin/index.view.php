<?php include "header/header.php" ?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Tempusdominus Bootstrap 4 -->
<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
<!-- iCheck -->
<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<!-- JQVMap -->
<link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="dist/css/adminlte.min.css">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
<!-- Daterange picker -->
<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
<!-- summernote -->
<link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
<title>Панель администратора</title>
<?php if ($user): ?>
    <section class="content m-5">
        <div class="container-fluid">
            <h2>Панель администратора</h2>
            <div class="row">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3><?= $orders_count ?></h3>

                            <p>Заказы</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars text-white"></i>
                        </div>
                        <a href="#" class="small-box-footer">Подробнее</a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3><?= $todays_orders_count ?></h3>

                            <p>Заказы за сегодня</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars text-white"></i>
                        </div>
                        <a href="#" class="small-box-footer">Подробнее</a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3><?= $products_count ?></h3>

                            <p>Товары</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag text-white"></i>
                        </div>
                        <a href="/admin/products" class="small-box-footer">Подробнее</a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3><?= $users_count ?></h3>

                            <p>Пользователи</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add text-white" ></i>
                        </div>
                        <a href="/admin/users/" class="small-box-footer">Подробнее</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php else: ?>
    <link href="/admin/admin_auth/signin.css" rel="stylesheet">

    <main class="form-signin text-center">
        <form action="/admin/admin_auth/login.php" method="post">
            <a href="/">
                <img class="mb-4" src="/images/logo.png" alt="" width="72" height="57">
            </a>
            <h1 class="h3 mb-3 fw-normal">Авторизация</h1>

            <div class="form-floating">
                <input type="email" class="form-control" name="email" placeholder="Введите email"
                       value="<?= $_SESSION['email'] ?>" required>
                <label for="floatingInput">Email</label>
            </div>
            <div class="form-floating my-3">
                <input type="password" class="form-control" id="floatingPassword" name="password"
                       placeholder="Введите пароль" required>
                <label for="floatingPassword">Пароль</label>
            </div>

            <div class="checkbox mb-3">
                <label>
                    <input type="checkbox" value="remember-me"> Запомнить
                </label>
            </div>
            <?php if ($_SESSION['errors']['auth']): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $_SESSION['errors']['auth'] ?>
                </div>
            <?php else: ?>
            <?php endif ?>
            <button class="w-100 btn btn-lg btn-dark" name="submit" type="submit">Войти</button>
            <p class="mt-5 mb-3 text-muted">&copy; 2019–2022</p>
        </form>
    </main>


<?php endif ?>
