<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
//var_dump($_SESSION);
$orders_count = count($dataOrder->getAllOrders());
$products_count = count($dataProduct->getProducts());
$users_count = count($dataUser->getUsers());
$today = (new DateTime())->format('Y-m-d');
$todays_orders_count = count($dataOrder->getOrdersByDate($today));
include $_SERVER['DOCUMENT_ROOT'] . '/admin/index.view.php';