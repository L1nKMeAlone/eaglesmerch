<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>Главная</title>

<div class="wrapper">
    <main class="main-content">
        <!--== Start Hero Area Wrapper ==-->
        <section class="home-slider-area">
            <div class="swiper-container swiper-slide-gap home-slider-container default-slider-container">
                <div class="swiper-wrapper home-slider-wrapper slider-default">
                    <div class="swiper-slide">
                        <div class="slider-content-area" data-bg-img="/images/first_slide.jpg">

                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-content-area" data-bg-img="assets/img/slider/slider-02.jpg">
                            <div class="slider-content">
                                <h5 class="sub-title">BEST PRICE : $866</h5>
                                <h2 class="title">NEW ARRIVAL</h2>
                                <h4>70% OFF THIS WINTER</h4>
                                <p>There are many variations of passages of Lorem Ipsum availables, but the majority
                                    have suffered alteration in some form.</p>
                                <a class="btn-slider" href="shop.html">Shop Now</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--== Add Swiper Arrows ==-->
                <div class="swiper-button-next"><i class="ion-ios7-arrow-right"></i></div>
                <div class="swiper-button-prev"><i class="ion-ios7-arrow-left"></i></div>
            </div>
        </section>
        <!--== End Hero Area Wrapper ==-->

        <!--== Start Single Banner Wrapper ==-->
        <section class="my-5">
            <div class="container pt-0 pb-0">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="single-banner-image">
                            <a href="/products/forMans">
                                <img style="width: 570px; height: 355px;" src="/images/for_mans.jpg" alt="Image-HasTech">
                            </a>
                            <h5 class="text-center my-2">Мужчинам</h5>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="single-banner-image mb-0">
                            <a href="shop.html">
                                <img style="width: 570px; height: 355px;" src="/images/for_womans.jpg" alt="Image-HasTech">
                                <h5 class="text-center my-2">Женщинам</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="single-banner-image mb-0">
                            <a href="shop.html">
                                <img style="width: 570px; height: 355px;" src="/images/for_children.jpg" alt="Image-HasTech">
                                <h5 class="text-center my-2">Детям</h5>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--== End Single Banner Wrapper ==-->

        <!--== Start Product Area Wrapper ==-->
        <section class="product-area">
            <div class="container product-pb" data-padding-bottom="25">
                <div class="row">
                    <div class="col-12">
                        <div class="product-category-tab-wrap">
                            <ul class="nav nav-tabs product-category-nav justify-content-center" id="myTab"
                                role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="best-seller-tab" data-bs-toggle="tab"
                                            data-bs-target="#bestSeller" type="button" role="tab"
                                            aria-controls="bestSeller" aria-selected="true">
                                        Бестселлеры
                                    </button>
                                </li>

                            </ul>
                            <div class="tab-content product-category-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="bestSeller" role="tabpanel"
                                     aria-labelledby="best-seller-tab">
                                    <div class="row">
                                        <div class="col-12">

                                            <div class="swiper-container swiper-slide-gap product-slider-container">

                                                <div class="swiper-wrapper">
                                                    <?php foreach ($tshirts as $tshirt): ?>
                                                        <div class="swiper-slide">
                                                            <div class="product-item">
                                                                <div class="inner-content">
                                                                    <div class="product-thumb">
                                                                        <a href="/products/detailed?id=<?= $tshirt->id ?>">
                                                                            <img class="w-100"
                                                                                 src="/images/<?= $dataImage->getProductImage($tshirt->id)->image ?>"
                                                                                 alt="Image-HasTech">
                                                                        </a>
                                                                    </div>
                                                                    <div class="product-desc">
                                                                        <div class="product-info">
                                                                            <h4 class="title">
                                                                                <a href="/products/detailed?id=<?= $tshirt->id ?>">
                                                                                    <?= $tshirt->name ?>
                                                                                </a>
                                                                            </h4>
                                                                            <div class="prices">
                                                                                <span class="price">
                                                                                    <?= $tshirt->price ?> ₽
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                        </div>
                                                    <?php endforeach ?>
                                                </div>

                                                <!--== Add Swiper navigation Buttons ==-->
                                                <div class="swiper-button-prev"><i
                                                            class="ei ei-icon_arrow_carrot-left"></i></div>
                                                <div class="swiper-button-next"><i
                                                            class="ei ei-icon_arrow_carrot-right"></i></div>

                                            </div>
                                            <div class="swiper-container swiper-slide-gap product-slider-container">
                                                <div class="swiper-wrapper">
                                                    <?php foreach ($sweatshirts as $sweatshirt): ?>
                                                        <div class="swiper-slide">
                                                            <div class="product-item">
                                                                <div class="inner-content">
                                                                    <div class="product-thumb">
                                                                        <a href="/products/detailed?id=<?= $sweatshirt->id ?>">
                                                                            <img class="w-100"
                                                                                 src="/images/<?= $dataImage->getProductImage($sweatshirt->id)->image ?>"
                                                                                 alt="Image-HasTech">
                                                                        </a>
                                                                    </div>
                                                                    <div class="product-desc">
                                                                        <div class="product-info">
                                                                            <h4 class="title">
                                                                                <a href="/products/detailed?id=<?= $sweatshirt->id ?>">
                                                                                    <?= $sweatshirt->name ?>
                                                                                </a>
                                                                            </h4>
                                                                            <div class="prices">
                                                                                <span class="price">
                                                                                    <?= $sweatshirt->price ?> ₽
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach ?>
                                                </div>

                                                <!--== Add Swiper navigation Buttons ==-->
                                                <div class="swiper-button-prev"><i
                                                            class="ei ei-icon_arrow_carrot-left"></i></div>
                                                <div class="swiper-button-next"><i
                                                            class="ei ei-icon_arrow_carrot-right"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--== End Product Area Wrapper ==-->



        <!--== Start Product Area Wrapper ==-->
        <section class="product-area product-new-arrivals-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 m-auto">
                        <div class="section-title text-center">
                            <h2 class="title">Новые аксессуары</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="swiper-container swiper-slide-gap product-slider-container">
                            <div class="swiper-wrapper">
                                <?php foreach($accessories as $accessory): ?>
                                    <div class="swiper-slide">
                                        <!--== Start Shop Item ==-->
                                        <div class="product-item">
                                            <div class="inner-content">
                                                <div class="product-thumb">
                                                    <a href="/products/detailed?id=<?= $accessory->id ?>">
                                                        <img class="w-100" src="/images/<?= $dataImage->getProductImage($accessory->id)->image ?>"
                                                             alt="Image-HasTech">
                                                    </a>
                                                </div>
                                                <div class="product-desc">
                                                    <div class="product-info">
                                                        <h4 class="title">
                                                            <a href="/products/detailed?id=<?= $accessory->id ?>">
                                                                <?= $accessory->name ?>
                                                            </a>
                                                        </h4>
                                                        <div class="prices">
                                                            <span class="price"> <?= $accessory->price ?> ₽</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--== End Shop Item ==-->
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <!--== Add Swiper navigation Buttons ==-->
                            <div class="swiper-button-prev"><i class="ei ei-icon_arrow_carrot-left"></i></div>
                            <div class="swiper-button-next"><i class="ei ei-icon_arrow_carrot-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--== End Product Area Wrapper ==-->

        <!--== Start Feature Area Wrapper ==-->
        <section class="feature-area">
            <div class="container pb-1">
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <!--== Start Feature Item ==-->
                        <div class="feature-icon-box">
                            <div class="inner-content">
                                <div class="icon-box">
                                    <i class="icon ei ei-icon_pin_alt"></i>
                                </div>
                                <div class="content">
                                    <h5 class="title">Free shipping worldwide</h5>
                                    <p>Freeship over oder $100</p>
                                </div>
                            </div>
                        </div>
                        <!--== End Feature Item ==-->
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <!--== Start Feature Item ==-->
                        <div class="feature-icon-box">
                            <div class="inner-content">
                                <div class="icon-box">
                                    <i class="icon ei ei-icon_headphones"></i>
                                </div>
                                <div class="content">
                                    <h5 class="title">Support 24/7</h5>
                                    <p>Contact us 24 hours a day</p>
                                </div>
                            </div>
                        </div>
                        <!--== End Feature Item ==-->
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <!--== Start Feature Item ==-->
                        <div class="feature-icon-box">
                            <div class="inner-content mb-0">
                                <div class="icon-box">
                                    <i class="icon ei ei-icon_creditcard"></i>
                                </div>
                                <div class="content">
                                    <h5 class="title">100% secure payment</h5>
                                    <p>Your payment are safe with us.</p>
                                </div>
                            </div>
                        </div>
                        <!--== End Feature Item ==-->
                    </div>
                </div>
            </div>
        </section>
        <!--== End Feature Area Wrapper ==-->

    </main>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/footer/footer.php'; ?>
</div>