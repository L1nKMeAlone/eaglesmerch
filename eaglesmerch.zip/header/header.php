<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">

    <!--== Google Fonts ==-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,500,500i,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,500,600,700" rel="stylesheet">

    <!--== Bootstrap CSS ==-->
    <link href="/header/assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!--== Headroom CSS ==-->
    <link href="/header//assets/css/headroom.css" rel="stylesheet"/>
    <!--== Animate CSS ==-->
    <link href="/header//assets/css/animate.css" rel="stylesheet"/>
    <!--== Ionicons CSS ==-->
    <link href="/header//assets/css/ionicons.css" rel="stylesheet"/>
    <!--== Material Icon CSS ==-->
    <link href="/header//assets/css/material-design-iconic-font.css" rel="stylesheet"/>
    <!--== Elegant Icon CSS ==-->
    <link href="/header//assets/css/elegant-icons.css" rel="stylesheet"/>
    <!--== Font Awesome Icon CSS ==-->
    <link href="/header//assets/css/font-awesome.min.css" rel="stylesheet"/>
    <!--== Swiper CSS ==-->
    <link href="/header//assets/css/swiper.min.css" rel="stylesheet"/>
    <!--== Fancybox Min CSS ==-->
    <link href="/header//assets/css/fancybox.min.css" rel="stylesheet"/>
    <!--== Slicknav Min CSS ==-->
    <link href="/header//assets/css/slicknav.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <!--== Main Style CSS ==-->
    <link href="/header//assets/css/style.css" rel="stylesheet"/>
    <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <!--=======================Javascript============================-->

    <!--=== jQuery Modernizr Min Js ===-->
    <script src="/header/assets/js/modernizr.js" defer></script>
    <!--=== jQuery Min Js ===-->
    <script src="/header/assets/js/jquery-main.js" defer></script>
    <!--=== jQuery Migration Min Js ===-->
    <script src="/header/assets/js/jquery-migrate.js" defer></script>
    <!--=== jQuery Popper Min Js ===-->
    <script src="/header/assets/js/popper.min.js" defer></script>
    <!--=== jQuery Bootstrap Min Js ===-->
    <script src="/header/assets/js/bootstrap.min.js" defer></script>
    <!--=== jQuery Headroom Min Js ===-->
    <script src="/header/assets/js/headroom.min.js" defer></script>
    <!--=== jQuery Swiper Min Js ===-->
    <script src="/header/assets/js/swiper.min.js" defer></script>
    <!--=== jQuery Fancybox Min Js ===-->
    <script src="/header/assets/js/fancybox.min.js" defer></script>
    <!--=== jQuery Slick Nav Js ===-->
    <script src="/header/assets/js/slicknav.js" defer></script>
    <!--=== jQuery Countdown Js ===-->
    <script src="/header/assets/js/countdown.js" defer></script>

    <!--=== jQuery Custom Js ===-->
    <script src="/header/assets/js/custom.js" defer></script>

</head>
<body>

<header class="header-area header-default sticky-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-6 col-sm-4 col-lg-3">
                <div class="header-logo-area">
                    <a href="/">
                        <img class="logo-main" src="/images/logo.png" style="width: 75px;" alt="Logo"/>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-lg-7 d-none d-lg-block">
                <div class="header-navigation-area">
                    <ul class="main-menu nav position-relative">
                        <li class="has-submenu"><a href="/">Главная</a></li>
                        <li class="has-submenu full-width"><a href="#/">Каталог</a>
                            <ul class="submenu-nav submenu-nav-mega">
                                <li class="mega-menu-item"><a href="#/" class="mega-title">Мужчинам</a>
                                    <ul>
                                        <li><a href="shop-3-grid.html">Футболки</a></li>
                                        <li><a href="shop-4-grid.html">Толстовки</a></li>
                                        <li><a href="shop-4-grid.html">Худи</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu-item"><a href="#/" class="mega-title">Женщинам</a>
                                    <ul>
                                        <li><a href="login.html">Футболки</a></li>
                                        <li><a href="wishlist.html">Толстовки</a></li>
                                        <li><a href="shop-4-grid.html">Худи</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu-item"><a href="#/" class="mega-title">Детям</a>
                                    <ul>
                                        <li><a href="login.html">Футболки</a></li>
                                        <li><a href="wishlist.html">Толстовки</a></li>
                                        <li><a href="shop-4-grid.html">Худи</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu-item"><a href="#/" class="mega-title">Аксессуары</a>
                                    <ul>
                                        <li><a href="login.html">Брелоки</a></li>
                                        <li><a href="wishlist.html">Значки</a></li>
                                        <li><a href="login.html">Браслеты</a></li>
                                        <li><a href="login.html">Кружки</a></li>
                                        <li><a href="login.html">Рюкзаки</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="has-submenu"><a href="/aboutUs">О нас</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-7 col-lg-2 d-none d-sm-block text-end">
                <div class="header-action-area">
                    <ul class="header-action">
                        <?php if ($user): ?>
                            <li class="search-item">
                                <a class="action-item" href="/profile">
                                    <i class="bi bi-person-circle"></i>
                                </a>
                            </li>
                            <li class="search-item">
                                <a class="action-item" href="/auth/index.php">
                                    <i class="bi bi-box-arrow-right"></i>
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="search-item">
                                <a class="action-item" data-bs-toggle="modal" href="#exampleModalToggle">
                                    <i class="bi bi-person-circle"></i>
                                </a>
                            </li>
                        <?php endif ?>
                        <li class="mini-cart">
                            <a class="action-item" href="/profile/cart">
                                <i class="bi bi-bag"></i>
                                <span class="cart-quantity">
                                    <?= count($dataProduct->getUserProducts($user->id)) ?>
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-6 col-sm-1 d-block d-lg-none text-end">
                <button class="btn-menu" type="button"><i class="zmdi zmdi-menu"></i></button>
            </div>
        </div>
    </div>
</header>

<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
     tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel">Авторизация</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <main class="form-signin text-center">
                    <form action="/auth/login.php" method="post">
                        <a href="/">
                            <img class="mb-4" src="/images/logo.png" alt="" width="72" height="57">
                        </a>
                        <h1 class="h3 mb-3 fw-normal">Авторизация</h1>

                        <div class="form-floating">
                            <input type="email" class="form-control" name="email" placeholder="Введите email" required>
                            <label for="floatingInput">Email</label>
                        </div>
                        <div class="form-floating my-3">
                            <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Введите пароль" required>
                            <label for="floatingPassword">Пароль</label>
                        </div>
                        <div class="checkbox mb-3 my-3">
                            <label>
                                <input type="checkbox" value="remember-me"> Запомнить
                            </label>
                        </div>
                        <?php if ($_SESSION['errors']['auth']): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= $_SESSION['errors']['auth'] ?>
                            </div>
                        <?php else: ?>
                        <?php endif ?>
                        <button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Войти</button>
                    </form>
                </main>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal"
                        data-bs-dismiss="modal">Регистрация
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2"
     tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel2">Регистрация</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <main class="form-signin text-center">
                    <form action="/register/register.php" method="post">
                        <a href="/">
                            <img class="mb-4" src="/images/logo.png" alt="" width="72" height="57">
                        </a>
                        <h1 class="h3 mb-3 fw-normal">Регистрация</h1>

                        <div class="form-floating">
                            <input type="text" class="form-control" name="name" placeholder="Введите имя" required>
                            <label for="floatingInput">Имя</label>
                        </div>
                        <div class="form-floating">
                            <input type="text" class="form-control" name="surname" placeholder="Введите фамилию"
                                   required>
                            <label for="floatingInput">Фамилия</label>
                        </div>
                        <div class="form-floating">
                            <input type="email" class="form-control" name="email" placeholder="Введите email" required>
                            <label for="floatingInput">Email</label>
                        </div>
                        <div class="form-floating">
                            <input type="text" class="form-control tel" name="phone_number"
                                   placeholder="Введите номер телефона" value="" required>
                            <label for="floatingInput">Номер телефона</label>
                        </div>
                        <div class="form-floating">
                            <input type="password" class="form-control" id="floatingPassword" name="password"
                                   placeholder="Введите пароль" required>
                            <label for="floatingPassword">Пароль</label>
                        </div>
                        <div class="form-floating">
                            <input type="password" class="form-control" name="password_repeat"
                                   placeholder="Повторите пароль" required>
                            <label for="floatingInput">Повторите пароль</label>
                        </div>
                        <br>

                        <?php if ($_SESSION['errors']['register']): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= $_SESSION['errors']['register'] ?>
                            </div>
                        <?php else: ?>
                        <?php endif ?>
                        <button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Зарегистрироваться
                        </button>
                    </form>
                </main>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal"
                        data-bs-dismiss="modal">Авторизация
                </button>
            </div>
        </div>
    </div>
</div>

<aside class="off-canvas-wrapper">
    <div class="off-canvas-inner">
        <div class="off-canvas-overlay"></div>
        <!-- Start Off Canvas Content Wrapper -->
        <div class="off-canvas-content">
            <!-- Off Canvas Header -->
            <div class="off-canvas-header">
                <div class="close-action">
                    <button class="btn-menu-close">menu <i class="fa fa-chevron-left"></i></button>
                </div>
            </div>

            <div class="off-canvas-item">
                <!-- Start Mobile Menu Wrapper -->
                <div class="res-mobile-menu menu-active-one">
                    <!-- Note Content Auto Generate By Jquery From Main Menu -->
                </div>
                <!-- End Mobile Menu Wrapper -->
            </div>
        </div>
        <!-- End Off Canvas Content Wrapper -->
    </div>
</aside>

<script>
    window.addEventListener("DOMContentLoaded", function () {
        [].forEach.call(document.querySelectorAll('.tel'), function (input) {
            var keyCode;

            function mask(event) {
                event.keyCode && (keyCode = event.keyCode);
                var pos = this.selectionStart;
                if (pos < 3) event.preventDefault();
                var matrix = "+7 (___) ___ ____",
                    i = 0,
                    def = matrix.replace(/\D/g, ""),
                    val = this.value.replace(/\D/g, ""),
                    new_value = matrix.replace(/[_\d]/g, function (a) {
                        return i < val.length ? val.charAt(i++) || def.charAt(i) : a
                    });
                i = new_value.indexOf("_");
                if (i != -1) {
                    i < 5 && (i = 3);
                    new_value = new_value.slice(0, i)
                }
                var reg = matrix.substr(0, this.value.length).replace(/_+/g,
                    function (a) {
                        return "\\d{1," + a.length + "}"
                    }).replace(/[+()]/g, "\\$&");
                reg = new RegExp("^" + reg + "$");
                if (!reg.test(this.value) || this.value.length < 5 || keyCode > 47 && keyCode < 58) this.value = new_value;
                if (event.type == "blur" && this.value.length < 5) this.value = ""
            }

            input.addEventListener("input", mask, false);
            input.addEventListener("focus", mask, false);
            input.addEventListener("blur", mask, false);
            input.addEventListener("keydown", mask, false)

        });

    });


</script>

<script>
    function addToCart(user_id, product_id, count) {
        // var user_id = $('#user_id').val();
        // var product_id = $('#product_id').val();
        // var count = $('#count').val();
        $.ajax({
            type: "GET",
            url: "addToCart.php",
            data: {fuser_id: user_id, fproduct_id: product_id, f_count: count}
        }).done(function (result) {
            $("#msg").html("DA");
        });
    }
</script>
