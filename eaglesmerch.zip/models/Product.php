<?php

namespace App\models;

use PDO;

class Product
{
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function createProduct($name, $description, $price, $subcategory_id)
    {

        $stmt = $this->pdo->prepare("INSERT INTO products (name, description, price, subcategory_id) VALUES (:name, :description, :price, :subcategory_id)");
        $stmt->execute([
            'name' => $name,
            'description' => $description,
            'price' => $price,
            'subcategory_id' => $subcategory_id,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function deleteProduct($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);
    }

    public function getProducts()
    {
        $stmt = $this->pdo->query("SELECT * FROM products");

        return $stmt->fetchAll();
    }

    public function getTshirts()
    {
        $stmt = $this->pdo->query("SELECT * FROM products WHERE subcategory_id = 22 LIMIT 10");

        return $stmt->fetchAll();
    }

    public function getSweatshirts()
    {
        $stmt = $this->pdo->query("SELECT * FROM products WHERE subcategory_id = 23 LIMIT 10");

        return $stmt->fetchAll();
    }

    public function getAccessories()
    {
        $stmt = $this->pdo->query("SELECT * FROM products WHERE subcategory_id = 31 OR subcategory_id = 32 OR subcategory_id = 33 OR subcategory_id = 34 OR subcategory_id = 35 LIMIT 10");

        return $stmt->fetchAll();
    }

    public function getProductsBySubcategory($subcategory_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE subcategory_id = :subcategory_id");
        $stmt->execute([
            "subcategory_id" => $subcategory_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getALlProductsBySubcategory($subcategory_id)
    {
        $stmt = $this->pdo->prepare("SELECT p.*,
            (SELECT image FROM product_images pi WHERE pi.product_id = p.id LIMIT 1) as image
            FROM products p
            WHERE subcategory_id = :subcategory_id");
        $stmt->execute([
            "subcategory_id" => $subcategory_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getProduct($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);

        return $stmt->fetch();
    }

    public function getProductsInfo($subcategory_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE subcategory_id = :subcategory_id");
        $stmt->execute([
            'subcategory_id' => $subcategory_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getProductReviews($product_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM reviews WHERE product_id = :product_id");
        $stmt->execute([
            "product_id" => $product_id,
        ]);

        return $stmt->fetch();
    }

    public function createProductSize($product_id, $size_id, $count)
    {

        $stmt = $this->pdo->prepare("INSERT INTO product_sizes (product_id, size_id, count) VALUES (:product_id, :size_id, :count)");
        $stmt->execute([
            'product_id' => $product_id,
            'size_id' => $size_id,
            'count' => $count,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function createProductMaterial($product_id, $material_id, $value)
    {

        $stmt = $this->pdo->prepare("INSERT INTO product_materials (product_id, material_id, value) VALUES (:product_id, :material_id, :value)");
        $stmt->execute([
            'product_id' => $product_id,
            'material_id' => $material_id,
            'value' => $value,
        ]);
        return $this->pdo->lastInsertId();
    }


    public function getProductMaterials($product_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM product_materials INNER JOIN materials m on product_materials.material_id = m.id WHERE product_id = :product_id");
        $stmt->execute([
            "product_id" => $product_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getMaterialsName()
    {
        $stmt = $this->pdo->query("SELECT * FROM materials");

        return $stmt->fetchAll();
    }



    public function getProductSizes($product_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM product_sizes INNER JOIN sizes s on product_sizes.size_id = s.id WHERE product_id = :product_id");
        $stmt->execute([
            "product_id" => $product_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getSizesValue()
    {
        $stmt = $this->pdo->query("SELECT * FROM sizes");

        return $stmt->fetchAll();
    }

    public function deleteProductMaterial($pr_id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM product_materials WHERE pr_id = :pr_id");
        $stmt->execute([
            "pr_id" => $pr_id
        ]);
    }

    public function deleteProductSize($sz_id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM product_sizes WHERE sz_id = :sz_id");
        $stmt->execute([
            "sz_id" => $sz_id
        ]);
    }

    public function updateProductMaterial($pr_id, $value)
    {
        $stmt = $this->pdo->prepare("UPDATE product_materials SET value = :value WHERE pr_id = :pr_id");

        $stmt->execute([
            'pr_id' => $pr_id,
            'value' => $value,

        ]);
    }

    public function updateProductSize($sz_id, $count)
    {
        $stmt = $this->pdo->prepare("UPDATE product_sizes SET count = :count WHERE sz_id = :sz_id");

        $stmt->execute([
            'sz_id' => $sz_id,
            'count' => $count,

        ]);
    }

    public function updateProduct($id, $name, $description, $subcategory_id, $price)
    {
        $stmt = $this->pdo->prepare("UPDATE products SET name = :name, description = :description, subcategory_id = :subcategory_id, price = :price WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'name' => $name,
            'description' => $description,
            'subcategory_id' => $subcategory_id,
            'price' => $price,

        ]);
    }

    public function addToCart($user_id, $product_id, $count, $size_id)
    {

        $stmt = $this->pdo->prepare("INSERT INTO cart (user_id, product_id, count, size_id) VALUES (:user_id, :product_id, :count, :size_id)");
        $stmt->execute([
            'user_id' => $user_id,
            'product_id' => $product_id,
            'count' => $count,
            'size_id' => $size_id,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function findProductInCart($user_id, $product_id, $size_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM cart WHERE user_id = :user_id AND product_id = :product_id AND size_id = :size_id");
        $stmt->execute([
            'user_id' => $user_id,
            'product_id' => $product_id,
            'size_id' => $size_id,
        ]);

        return $stmt->fetch();
    }

    public function updateProductInCart($user_id, $product_id, $count, $size_id)
    {
        $stmt = $this->pdo->prepare("UPDATE cart SET count = :count WHERE user_id = :user_id AND product_id = :product_id AND size_id = :size_id");
        $stmt->execute([
            'user_id' => $user_id,
            'product_id' => $product_id,
            'count' => $count,
            'size_id' => $size_id,
        ]);
    }

    public function getUserProducts($user_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM cart INNER JOIN products p on cart.product_id = p.id INNER JOIN sizes s on cart.size_id = s.id WHERE user_id = :user_id");
        $stmt->execute([
            'user_id' => $user_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getDelivery()
    {
        $stmt = $this->pdo->query("SELECT * FROM delivery");

        return $stmt->fetchAll();
    }

    public function deleteProductFromCart($user_id, $product_id, $size_id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM cart WHERE user_id = :user_id AND product_id = :product_id AND size_id = :size_id");
        $stmt->execute([
            'user_id' => $user_id,
            'product_id' => $product_id,
            'size_id' => $size_id
        ]);
    }

    public function getProductsForMans()
    {
        $stmt = $this->pdo->query("SELECT * FROM products WHERE subcategory_id = 22 OR subcategory_id = 23 OR subcategory_id = 24");

        return $stmt->fetchAll();
    }


}
