<?php
namespace App\models;
use PDO;

class User {
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function findUserEmailForRegister($email) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute([
            'email' => $email,
        ]);

        return $stmt->fetchAll();
    }

    public function findUserPhoneForRegister($phone_number) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE phone_number = :phone_number");
        $stmt->execute([
            'phone_number' => $phone_number,
        ]);

        return $stmt->fetchAll();
    }

    public function getUsers(){
        $stmt = $this->pdo->query("SELECT * FROM users");

        return $stmt->fetchAll();
    }

    public function getUser($id){
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute([
            'id' => $id,
        ]);
        return $stmt->fetch();
    }

    public function getUserRoles(){
        $stmt = $this->pdo->query("SELECT * FROM roles");

        return $stmt->fetchAll();
    }

    public function updateUserRole($id, $role_id)
    {
        $stmt = $this->pdo->prepare("UPDATE users SET role_id = :role_id WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'role_id' => $role_id,
        ]);
    }

    public function changeEmail($id, $newEmail)
    {
        $stmt = $this->pdo->prepare("UPDATE users SET email = :newEmail WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'newEmail' => $newEmail,
        ]);
    }

    public function changePhoneNumber($id, $newPhoneNumber)
    {
        $stmt = $this->pdo->prepare("UPDATE users SET phone_number = :newPhoneNumber WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'newPhoneNumber' => $newPhoneNumber,
        ]);
    }

    public function changePassword($id, $newPassword)
    {
        $stmt = $this->pdo->prepare("UPDATE users SET password = :newPassword WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'newPassword' => password_hash($newPassword, PASSWORD_DEFAULT),
        ]);
    }

}

