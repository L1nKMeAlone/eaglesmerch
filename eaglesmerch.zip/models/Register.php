<?php
namespace App\models;
use PDO;

class Register {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function register($name, $surname, $phone_number, $email, $password, $image) {
        $stmt = $this->pdo->prepare("INSERT INTO users (name, surname, phone_number, email, password, image) values(:name, :surname, :phone_number, :email, :password, :image)");
        $stmt->execute([
            'name' => $name,
            'surname' => $surname,
            'phone_number' => $phone_number,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'image' => $image,
        ]);
        return $this->pdo->lastInsertId();
    }
}