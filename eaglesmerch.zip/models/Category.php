<?php
namespace App\models;
use PDO;

class Category {
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function createCategory($name, $image) {

        $stmt = $this->pdo->prepare("INSERT INTO categories (name, image) VALUES (:name, :image)");
        $stmt->execute([
            'name' => $name,
            'image' => $image,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function getCategories(){
        $stmt = $this->pdo->query("SELECT * FROM categories");

        return $stmt->fetchAll();
    }

    public function deleteCategory($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM categories WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);
    }

    public function getCategory($id){
        $stmt = $this->pdo->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);

        return $stmt->fetch();
    }

    public function updateCategory($id, $name, $image)
    {
        $stmt = $this->pdo->prepare("UPDATE categories SET name = :name, image = :image WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'name' => $name,
            'image' => $image,

        ]);
    }

    public function getCategoryForSubcategory($id){
        $stmt = $this->pdo->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);

        return $stmt->fetch();
    }

//    public function getCategoryOldImage($id){
//        $stmt = $this->pdo->prepare("SELECT image FROM categories WHERE id = :id");
//        $stmt->execute([
//            "id" => $id,
//        ]);
//
//        return $stmt->fetch();
//    }



}