<?php
namespace App\models;
use PDO;

class Order {
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function makeOrder($user_id, $final_price, $address, $date_of_registration, $delivery_id, $status_id) {

        $stmt = $this->pdo->prepare("INSERT INTO orders (user_id, final_price, address, date_of_registration, delivery_id, status_id) VALUES (:user_id, :final_price, :address, :date_of_registration, :delivery_id, :status_id)");
        $stmt->execute([
            'user_id' => $user_id,
            'final_price' => $final_price,
            'address' => $address,
            'date_of_registration' => $date_of_registration,
            'delivery_id' => $delivery_id,
            'status_id' => $status_id,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function addOrderedProduct($order_id, $product_id, $size_id, $count, $price) {

        $stmt = $this->pdo->prepare("INSERT INTO ordered_products (order_id, product_id, size_id, count, price) VALUES (:order_id, :product_id, :size_id, :count, :price)");
        $stmt->execute([
            'order_id' => $order_id,
            'product_id' => $product_id,
            'size_id' => $size_id,
            'count' => $count,
            'price' => $price,
        ]);
    }

    public function deleteAllProductsFromCart($user_id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM cart WHERE user_id = :user_id");
        $stmt->execute([
            'user_id' => $user_id,
        ]);
    }

    public function getUserOrders($user_id){
        $stmt = $this->pdo->prepare("SELECT o.id as id, o.date_of_registration, os.name, o.status_id FROM orders o INNER JOIN order_status os on o.status_id = os.id WHERE o.user_id = :user_id order by o.id desc");
        $stmt->execute([
            "user_id" => $user_id
        ]);

        return $stmt->fetchAll();
    }

    public function getOrderedProducts($order_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM ordered_products INNER JOIN sizes s on ordered_products.size_id = s.id WHERE order_id = :order_id");
        $stmt->execute([
            "order_id" => $order_id,
        ]);

        return $stmt->fetchAll();
    }

    public function getUserOrder($order_id){
        $stmt = $this->pdo->prepare("SELECT o.id as id, o.date_of_registration, os.name, o.user_id, o.delivery_id FROM orders o INNER JOIN order_status os on o.status_id = os.id WHERE o.id = :id");
        $stmt->execute([
            "id" => $order_id,
        ]);

        return $stmt->fetch();
    }

    public function getOrderStatuses(){
        $stmt = $this->pdo->query("SELECT * FROM order_status");

        return $stmt->fetchAll();
    }

    public function updateOrderStatus($id, $status_id)
    {
        $stmt = $this->pdo->prepare("UPDATE orders SET status_id = :status_id WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'status_id' => $status_id,
        ]);
    }

    public function getAllOrders(){
        $stmt = $this->pdo->query("SELECT * FROM orders");

        return $stmt->fetchAll();
    }

    public function getOrdersByDate($date_of_registration){
        $stmt = $this->pdo->prepare("SELECT * FROM orders WHERE date_of_registration = :date_of_registration");
        $stmt->execute([
            "date_of_registration" => $date_of_registration,
        ]);

        return $stmt->fetchAll();
    }

    public function getOrderDelivery($delivery_id){
        $stmt = $this->pdo->prepare("SELECT * FROM delivery WHERE id = :id");
        $stmt->execute([
            "id" => $delivery_id,
        ]);
        return $stmt->fetch();
    }


}

