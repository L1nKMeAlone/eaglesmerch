<?php

namespace App\models;

use PDO;

class Image
{
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function
    loadImage($validFiletypes, $uploadPath, $nameElem): array
    {
        $error = [];
        $newName = "";
        $uploadFiles = [];
//        var_dump($_FILES[$nameElem]);
        if (isset($_FILES[$nameElem])) {
            $file = $_FILES[$nameElem];
            for ($i = 0, $n = count($file['name']); $i < $n; $i++) {
                if ($file['error'][$i] !== 0) {
                    $error[] = "Произошла ошибка загрузки данных...";
                    break;
                } else {
                    $type = mime_content_type($file['tmp_name'][$i]);
                    $name = pathinfo($file["name"][$i], PATHINFO_FILENAME) . '_' . time();
                    $ext = pathinfo($file["name"][$i], PATHINFO_EXTENSION);
                    $newName = "$name.$ext";
                    $uploadFiles[] = $newName;
                    if (in_array($type, $validFiletypes)) {
                        if (!move_uploaded_file($file['tmp_name'][$i], $uploadPath . $newName)) {
                            $error[] = "Не удалось загрузить изображение...";
                        }
                    } else {
                        $error = "Расширение файла должно быть таким: jpg, jpeg или png";
                    }
                };
            }


//            if (!empty($error)) {
//                $error = $file['name'] . '_' . $error;
//            }
        }
        return [$error, $uploadFiles];
    }

    function deleteImage($path)
    {
        if (strlen($path) > 0) {
            unlink($path);
        } else {
            return "cannot delete";
        }

    }

    public function createImagesFromProduct($product_id, $image) {

        $stmt = $this->pdo->prepare("INSERT INTO product_images (product_id ,image) VALUES (:product_id, :image)");
        $stmt->execute([
            'product_id' => $product_id,
            'image' => $image,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function getProductImage($product_id){
        $stmt = $this->pdo->prepare("SELECT * FROM product_images WHERE product_id = :product_id");
        $stmt->execute([
            'product_id' => $product_id,
        ]);
        return $stmt->fetch();
    }

    public function getProductImages($product_id){
        $stmt = $this->pdo->prepare("SELECT * FROM product_images WHERE product_id = :product_id");
        $stmt->execute([
            'product_id' => $product_id,
        ]);
        return $stmt->fetchAll();
    }




}