<?php
namespace App\models;
use PDO;

class Subcategory {
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function createSubcategory($name, $category_id, $image) {

        $stmt = $this->pdo->prepare("INSERT INTO subcategories (name, category_id, image) VALUES (:name, :category_id, :image)");
        $stmt->execute([
            'name' => $name,
            'category_id' => $category_id,
            'image' => $image,
        ]);
        return $this->pdo->lastInsertId();
    }

    public function getSubcategories(){
        $stmt = $this->pdo->query("SELECT * FROM subcategories");

        return $stmt->fetchAll();
    }

    public function getSubcategoriesInfo($category_id){
        $stmt = $this->pdo->prepare("SELECT * FROM subcategories WHERE category_id = :category_id");
        $stmt->execute([
            'category_id' => $category_id,
        ]);

        return $stmt->fetchAll();
    }

    public function deleteSubcategory($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM subcategories WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);
    }

    public function getSubcategory($id){
        $stmt = $this->pdo->prepare("SELECT * FROM subcategories WHERE id = :id");
        $stmt->execute([
            "id" => $id
        ]);

        return $stmt->fetch();
    }

    public function updateSubcategory($id, $name, $category_id, $image)
    {
        $stmt = $this->pdo->prepare("UPDATE subcategories SET name = :name, category_id = :category_id, image = :image WHERE id = :id");

        $stmt->execute([
            'id' => $id,
            'name' => $name,
            'category_id' => $category_id,
            'image' => $image,

        ]);
    }


}
