<!--== Start Footer Area Wrapper ==-->
<footer class="footer-area">
    <div class="footer-top-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <!--== Start widget Item ==-->
                    <div class="widget-item">
                        <div class="about-widget">
                            <div class="footer-logo-area">
                                <a href="index.html">
                                    <img class="logo-main" src="assets/img/logo.png" alt="Logo"/>
                                </a>
                            </div>
                            <p class="desc">Lorem ipsum dolor sit amet, consectet adipi elit, sed do eius tempor
                                incididun ut labore gthydolore.</p>
                            <ul>
                                <li><i class="ion-ios7-location-outline"></i> 184 Main Rd E, St Albans VIC 3021,
                                </li>
                                <li><i class="ion-ios7-email-outline"></i> <a href="mailto://info@example.com">info@example.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--== End widget Item ==-->
                </div>
                <div class="col-sm-6 col-lg-3">
                    <!--== Start widget Item ==-->
                    <div class="widget-item widget-item-one">
                        <h4 class="widget-title">INFORMATION</h4>
                        <div class="widget-menu-wrap">
                            <ul class="nav-menu">
                                <li><a href="shop.html">Specials</a></li>
                                <li><a href="shop.html">New products</a></li>
                                <li><a href="shop.html">Top sellers</a></li>
                                <li><a href="shop.html">Our stores</a></li>
                                <li><a href="contact.html">Contact us</a></li>
                            </ul>
                        </div>
                    </div>
                    <!--== End widget Item ==-->
                </div>
                <div class="col-sm-6 col-lg-3">
                    <!--== Start widget Item ==-->
                    <div class="widget-item widget-item-two">
                        <h4 class="widget-title">QUICK LINKS</h4>
                        <div class="widget-menu-wrap">
                            <ul class="nav-menu">
                                <li><a href="login.html">New User</a></li>
                                <li><a href="about-us.html">Help Center</a></li>
                                <li><a href="about-us.html">Refund Policy</a></li>
                                <li><a href="about-us.html">Report Spam</a></li>
                                <li><a href="login.html">Account</a></li>
                            </ul>
                        </div>
                    </div>
                    <!--== End widget Item ==-->
                </div>
                <div class="col-sm-6 col-lg-3">
                    <!--== Start widget Item ==-->
                    <div class="widget-item">
                        <h4 class="widget-title">newsletter</h4>
                        <div class="widget-newsletter">
                            <p>Sign up for our newsletter & promotions</p>
                            <div class="newsletter-form">
                                <form>
                                    <input type="email" class="form-control" placeholder="email@example.com">
                                    <button class="btn-submit" type="button">Subscribe</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--== End widget Item ==-->
                </div>
            </div>
        </div>

    </div>
    <!--== Start Footer Bottom ==-->
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p class="copyright">© 2021, <span>Julie</span>. Made with <i
                            class="fa fa-heart icon-heart"></i> by <a target="_blank"
                                                                      href="https://themeforest.net/user/codecarnival/portfolio">
                            Codecarnival</a></p>
                </div>
            </div>
        </div>
    </div>
    <!--== End Footer Bottom ==-->
</footer>

<div id="scroll-to-top" class="scroll-to-top"><span class="fa fa-angle-double-up"></span></div>

</body>
</html>