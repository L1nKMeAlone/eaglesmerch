<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['change_email'])) {
    $id = $_POST['id'];
    $newEmail = $_POST['newEmail'];
    $dataUser->changeEmail($id, $newEmail);
    $user->email = $newEmail;
    $_SESSION['user'] = json_encode($user, JSON_UNESCAPED_UNICODE);
    $_SESSION['success']['changeEmail'] = "Email успешно изменён!";
    header('Location: /profile?email=1');
}
