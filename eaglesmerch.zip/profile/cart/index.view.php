<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>Корзина</title>
<section class="h-100 h-custom" style="background-color: #eee;">
    <div style="width: 80%;" class="container-xl py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12">
                <div class="card card-registration card-registration-2" style="border-radius: 15px;">
                    <div class="card-body p-0">
                        <div class="row g-0">
                            <div class="<?= $products?'col-lg-8':'col-lg-12'?>">
                                <div class="p-5">
                                    <div class="d-flex justify-content-between align-items-center mb-5">
                                        <h1 class="fw-bold mb-0 text-black">Корзина</h1>
                                    </div>
                                    <hr class="my-4">
                                    <?php if(count($products) == 0): ?>
                                        <p>Корзина пуста...</p>
                                    <?php else: ?>
                                        <?php foreach($products as $product): ?>
                                            <div class="row mb-4 d-flex justify-content-between align-items-center">
                                                <div class="col-md-2 col-lg-2 col-xl-2 ">
                                                    <img src="/images/<?= $dataImage->getProductImage($product->product_id)->image ?>" class="img-fluid rounded-3" alt="<?= $product->name ?>">
                                                </div>
                                                <div class="col-md-3 col-lg-3 col-xl-3 ">
                                                    <h6 class="text-black mb-0"><?= $product->name ?></h6>
                                                    <h6 class="text-muted"><?= $product->value ?></h6>
                                                </div>
                                                <div class="col-md-3 col-lg-3 col-xl-2">
                                                    <input id="form1" min="1" name="quantity" value="<?= $product->count ?>"
                                                           type="number" data-product='<?= json_encode($product) ?>' class="form-control form-control-sm product-count"
                                                           onchange = "let newCount = this.value; location.href = 'updateProductCount.php?user_id=<?= $user->id ?>&product_id=<?= $product->product_id ?>&size_id=<?= $product->id ?>&count=' +newCount ;"/>
                                                </div>
                                                <div class="col-md-3 col-lg-3 col-xl-3">
                                                    <h6 class="text-black mb-0"><?= $product->count * $product->price ?> ₽</h6>
                                                    <h6 class="text-muted"><?= $product->price ?> ₽ за штуку</h6>
                                                </div>
                                                <div class="col-md-3 col-lg-3 col-xl-2 d-flex">
                                                    <a href="deleteProductFromCart.php?product_id=<?= $product->product_id ?>&size_id=<?= $product->id ?>">Удалить</a>
                                                </div>
                                            </div>

                                            <hr class="my-4">
                                        <?php endforeach; ?>
                                </div>
                            </div>
                            <form class="col-lg-4 bg-grey" action="makeOrder.php" method="post">
                                <div class="p-5">
                                    <h3 class="fw-bold mb-5 mt-2 pt-1">Итого</h3>
                                    <hr class="my-4">

                                    <div class="d-flex justify-content-between mb-4">
                                        <h5>Товары: <?= $products_count ?> шт.</h5>
                                        <h5><?= $final_price ?> ₽</h5>
                                    </div>

                                    <h5 class="mb-3">Доставка</h5>

                                    <div class="mb-4 pb-2">
                                        <select name="delivery_id" id="delivery_id" class="form-control cart-delivery">
                                            <?php foreach($delivery as $delivery_type): ?>
                                                <option value="<?= $delivery_type->id ?>"><?= $delivery_type->name?> (<?= $delivery_type->price ?>)</option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                    <div class="mb-4 pb-2 cart-address">
                                        <h5 class="mb-3">Адрес доставки</h5>
                                        <input type="text" class="form-control cart-address-input" name="address" placeholder="Введите адрес доставки...">
                                    </div>

                                    <hr class="my-4">

                                    <div class="d-flex justify-content-between mb-5">
                                        <h5>Итоговая цена</h5>
                                        <h5 class="cart-final-price"><?= $final_price ?> ₽</h5>
                                        <input type="hidden" value="<?= $final_price ?>" class="hidden-cart-final-price" name="final_price">
                                    </div>

                                    <div class="d-flex justify-content-between mb-5">
                                        <button type="submit" name="makeOrder" class="btn btn-dark btn-block btn-lg"
                                                data-mdb-ripple-color="dark">Оформить заказ</button>
                                    </div>
                                </div>
                            </form>
                                    <?php endif ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="http://code.jquery.com/jquery-latest.js"></script>

<script>
    price = $('.cart-final-price');
    hidden_price = $('.hidden-cart-final-price');
    $('.cart-address').css('display', 'none');
    $('.cart-delivery').on('change',function(){
        if($('.cart-delivery').val() === "2") {
            price.text(`${parseInt(hidden_price.val()) + 350} ₽`);
            hidden_price.val(parseInt(hidden_price.val()) + 350)
            $('.cart-address').css('display', 'block');

        } else {
            price.text(`${parseInt(hidden_price.val()) - 350} ₽`);
            hidden_price.val(parseInt(hidden_price.val()) - 350)
            $('.cart-address').css('display', 'none');
            $('.cart-address-input').val('');
        }


    })

</script>