<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

$user_id = $_GET['user_id'];
$product_id = $_GET['product_id'];
$size_id = $_GET['size_id'];
$newCount = $_GET['count'];

$dataProduct->updateProductInCart($user_id, $product_id, $newCount, $size_id);
header('Location: /profile/cart/index.php?id=' . $product_id);





