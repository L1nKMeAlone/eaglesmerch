<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';


if(isset($_POST['makeOrder'])) {
    $user_id = $user->id;
    $final_price = $_POST['final_price'];
    $delivery_id = $_POST['delivery_id'];
    $address = $_POST['address'];
    $date_of_registration = (new DateTime())->format('Y-m-d');
    $status_id = 1;

    $order = $dataOrder->makeOrder($user_id, $final_price, $address, $date_of_registration, $delivery_id , $status_id);

    $products = $dataProduct->getUserProducts($user_id);
    foreach ($products as $product) {
        $dataOrder->addOrderedProduct($order, $product->product_id, $product->id, $product->count, $product->price );
    }

    $dataOrder->deleteAllProductsFromCart($user_id);
    header('Location: /profile/cart/index.php?id=' . $user_id);



}