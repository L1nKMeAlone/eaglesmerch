<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

$user_id = $user->id;
$product_id = $_GET['product_id'];
$size_id = $_GET['size_id'];
$dataProduct->deleteProductFromCart($user_id, $product_id, $size_id);
header('Location: /profile/cart/index.php?id=' . $user_id);




