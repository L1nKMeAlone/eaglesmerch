<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$products = $dataProduct->getUserProducts($user->id);
$delivery = $dataProduct->getDelivery();
$products_count = 0;
$final_price = 0;
foreach ($products as $product) {
    $final_price += $product->count * $product->price;
    $products_count += $product->count;
}
include $_SERVER['DOCUMENT_ROOT'] . '/profile/cart/index.view.php';