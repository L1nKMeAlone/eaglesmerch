<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>Мои заказы</title>
<div class="container-xl px-4 mt-4">
    <nav class="nav nav-borders">
        <a class="nav-link active ms-0" href="/profile/">Профиль</a>
        <a class="nav-link" href="/profile/orders/">Заказы</a>

    </nav>
    <hr class="mt-0 mb-4">
    <?php if ($user): ?>
        <div class="row">
            <table class="table table-hover">
                <thead class="table-dark">
                <tr class="text-center">
                    <th>Номер заказа</th>
                    <th>Дата</th>
                    <th>Статус</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($orders as $order): ?>
                    <tr class="text-center align-middle">
                        <td>
                            <a class="nav-link" href="detailed/index.php?id=<?= $order->id ?>"><?= $order->id ?></a>
                        </td>
                        <td><?= $order->date_of_registration ?></td>
                        <td><?= $order->name ?></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-danger">Необходимо авторизироваться!</div>
    <?php endif ?>
</div>