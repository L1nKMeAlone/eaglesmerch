<?php
include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';
$orders = $dataOrder->getUserOrders($user->id);
include $_SERVER['DOCUMENT_ROOT'] . '/profile/orders/index.view.php';