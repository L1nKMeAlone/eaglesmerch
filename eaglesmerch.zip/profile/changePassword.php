<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['change_password'])) {
    $id = $_POST['id'];
    $newPassword = $_POST['newPassword'];
    $repeatNewPassword = $_POST['repeatNewPassword'];
    if($newPassword === $repeatNewPassword) {
        $dataUser->changePassword($id, $newPassword);
        $user->password = $newPassword;
        $_SESSION['user'] = json_encode($user, JSON_UNESCAPED_UNICODE);
        $_SESSION['success']['changePassword'] = "Пароль успешно изменён!";
        header('Location: /profile?password=1');
    } else {
        $_SESSION['errors']['changePassword'] = "Пароли не совпадают!";
        header('Location: /profile?password=0');
    }

}
