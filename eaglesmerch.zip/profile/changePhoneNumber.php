<?php

include $_SERVER['DOCUMENT_ROOT'] . '/bootstrap.php';

if(isset($_POST['change_phone_number'])) {
    $id = $_POST['id'];
    $newPhoneNumber = $_POST['newPhoneNumber'];
    $newPhoneNumber = str_replace( " " , "" , $newPhoneNumber);
    $newPhoneNumber = str_replace( "(" , "" , $newPhoneNumber);
    $newPhoneNumber = str_replace( ")" , "" , $newPhoneNumber);
    if(strlen($newPhoneNumber) === 12) {
        $dataUser->changePhoneNumber($id, $newPhoneNumber);
        $user->phone_number = $newPhoneNumber;
        $_SESSION['user'] = json_encode($user, JSON_UNESCAPED_UNICODE);
        $_SESSION['success']['changePhoneNumber'] = "Номер телефона успешно изменён!";
        header('Location: /profile?phone_number=1');
    } else {
        $_SESSION['errors']['changePhoneNumber'] = "Неверный формат номера телефона!";
        header('Location: /profile?phone_number=0');
    }


}
