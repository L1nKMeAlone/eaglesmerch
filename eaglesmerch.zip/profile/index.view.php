<?php include $_SERVER['DOCUMENT_ROOT'] . '/header/header.php'; ?>
<title>Мой профиль</title>
<div class="container-xl px-4 mt-4">
    <?php if ($_GET['email'] == "1"): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success']['changeEmail'] ?>
        </div>
    <?php endif ?>

    <?php if ($_GET['phone_number'] == "0"): ?>
        <div class="alert alert-danger">
            <?= $_SESSION['errors']['changePhoneNumber'] ?>
        </div>
    <?php endif ?>

    <?php if ($_GET['phone_number'] == "1"): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success']['changePhoneNumber'] ?>
        </div>
    <?php endif ?>

    <?php if ($_GET['password'] == "0"): ?>
        <div class="alert alert-danger">
            <?= $_SESSION['errors']['changePassword'] ?>
        </div>
    <?php endif ?>

    <?php if ($_GET['password'] == "1"): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success']['changePassword'] ?>
        </div>
    <?php endif ?>

    <nav class="nav nav-borders">
        <a class="nav-link active ms-0" href="/profile/">Профиль</a>
        <a class="nav-link" href="/profile/orders/">Заказы</a>
    </nav>
    <hr class="mt-0 mb-4">
    <?php if ($user): ?>
        <div class="row">
            <div class="col-xl-4">
                <div class="card mb-4 mb-xl-0">
                    <div class="card-header">Фото профиля</div>
                    <div class="card-body text-center">
                        <img class="img-account-profile rounded-circle mb-2"
                             src="/images/<?= $user->image ?>" alt="Фото профиля" draggable="false">
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="card mb-4">
                    <div class="card-header">Мои данные </div>
                    <div class="card-body">
                        <form>
                            <div class="row gx-3 mb-3">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputFirstName">Имя</label>
                                    <input class="form-control" id="inputFirstName" type="text" readonly
                                           value="<?= $user->name ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputLastName">Фамилия</label>
                                    <input class="form-control" id="inputLastName" type="text" readonly
                                           value="<?= $user->surname ?>">
                                </div>
                            </div>
                            <div class="row gx-3 mb-3">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputOrgName">Email</label>
                                </div>
                                <div class="col-md-6">

                                </div>
                                <div class="col-md-6">
                                    <input class="form-control" id="inputOrgName" type="text" readonly
                                           value="<?= $user->email ?>">
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="form-control btn btn-dark" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal">
                                        Изменить
                                    </button>
                                </div>
                            </div>
                            <div class="row gx-3 mb-3">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputOrgName">Номер телефона</label>
                                </div>
                                <div class="col-md-6">

                                </div>
                                <div class="col-md-6">
                                    <input class="form-control" id="inputOrgName" type="text" readonly
                                           value="<?= $user->phone_number ?>">
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="form-control btn btn-dark" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal2">
                                        Изменить
                                    </button>
                                </div>
                            </div>

                            <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal3">
                                Изменить пароль
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="changeEmail.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Изменить email</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Закрыть"></button>
                        </div>
                        <div class="modal-body">
                            <label class="small mb-1" for="inputFirstName">Новый Email</label>
                            <input class="form-control" id="inputFirstName" type="email" name="newEmail" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            <button type="submit" class="btn btn-primary" name="change_email">Сохранить</button>
                        </div>
                        <input type="hidden" name="id" value="<?= $user->id ?>">
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="changePhoneNumber.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Изменить номер телефона</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Закрыть"></button>
                        </div>
                        <div class="modal-body">
                            <label class="small mb-1" for="inputFirstName">Новый номер телефона</label>
                            <input class="form-control tel" id="inputFirstName" type="text" name="newPhoneNumber"
                                   required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            <button type="submit" class="btn btn-primary" name="change_phone_number">Сохранить</button>
                        </div>
                        <input type="hidden" name="id" value="<?= $user->id ?>">
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="changePassword.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Изменить пароль</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Закрыть"></button>
                        </div>
                        <div class="modal-body">
                            <label class="small mb-1" for="inputFirstName">Новый пароль</label>
                            <input class="form-control" id="inputFirstName" type="password" name="newPassword" required>
                        </div>
                        <div class="modal-body">
                            <label class="small mb-1" for="inputFirstName">Повторите новый пароль</label>
                            <input class="form-control" id="inputFirstName" type="password" name="repeatNewPassword" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            <button type="submit" class="btn btn-primary" name="change_password">Сохранить</button>
                        </div>
                        <input type="hidden" name="id" value="<?= $user->id ?>">
                    </form>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="alert alert-danger">Необходимо авторизироваться!</div>
    <?php endif ?>
</div>