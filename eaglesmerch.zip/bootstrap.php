<?php
session_start();
use App\db\Connect;
use App\models\Auth;
use App\models\Register;
use App\models\User;
use App\models\Category;
use App\models\Subcategory;
use App\models\Product;
use App\models\Image;
use App\models\Order;



include $_SERVER['DOCUMENT_ROOT'] . '/db/Connect.php';
include $_SERVER['DOCUMENT_ROOT'] . '/db/config.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Auth.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Register.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/User.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Category.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Subcategory.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Product.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Image.php';
include $_SERVER['DOCUMENT_ROOT'] . '/models/Order.php';
include $_SERVER['DOCUMENT_ROOT'] . '/other.php';


$user = isset($_SESSION['auth']) && $_SESSION['auth'] ? json_decode($_SESSION['user']) : false;
$uploadPath = $_SERVER['DOCUMENT_ROOT'] . "/images/";
$maxFileSize = 8*1024*1024;
$validFiletypes = ['image/jpg', 'image/jpeg', 'image/png'];

$pdo = Connect::make(CONN);
$dataAuth = new Auth($pdo);
$dataRegister = new Register($pdo);
$dataUser = new User(Connect::make(CONN));
$dataCategory = new Category(Connect::make(CONN));
$dataSubcategory = new Subcategory(Connect::make(CONN));
$dataProduct = new Product(Connect::make(CONN));
$dataImage = new Image(Connect::make(CONN));
$dataOrder = new Order(Connect::make(CONN));